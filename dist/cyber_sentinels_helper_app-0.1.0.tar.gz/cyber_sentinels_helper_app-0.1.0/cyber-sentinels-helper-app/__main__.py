#!/usr/bin/env python3

from CLI_Bot import Bot
bot = Bot()
run = bot.run()

if __name__ == "__main__":
    run()
